﻿namespace project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.sideBar = new System.Windows.Forms.Panel();
            this.firewall_tutorSettingsButton = new System.Windows.Forms.Button();
            this.firewall_tutorialButton = new System.Windows.Forms.Button();
            this.firewall_tutorHelpButton = new System.Windows.Forms.Button();
            this.panelMediaSubmenu = new System.Windows.Forms.Panel();
            this.firewall_tutorAboutButton = new System.Windows.Forms.Button();
            this.firewall_tutorViewRulesButton = new System.Windows.Forms.Button();
            this.firewall_tutorCheckPacketButton = new System.Windows.Forms.Button();
            this.firewall_tutorAddRuleButton = new System.Windows.Forms.Button();
            this.FirewallHome_button = new System.Windows.Forms.Button();
            this.panellogo = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelChildForm = new System.Windows.Forms.Panel();
            this.sideBar.SuspendLayout();
            this.panelMediaSubmenu.SuspendLayout();
            this.panellogo.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // sideBar
            // 
            this.sideBar.AutoScroll = true;
            this.sideBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.sideBar.Controls.Add(this.firewall_tutorSettingsButton);
            this.sideBar.Controls.Add(this.firewall_tutorialButton);
            this.sideBar.Controls.Add(this.firewall_tutorHelpButton);
            this.sideBar.Controls.Add(this.panelMediaSubmenu);
            this.sideBar.Controls.Add(this.FirewallHome_button);
            this.sideBar.Controls.Add(this.panellogo);
            this.sideBar.Dock = System.Windows.Forms.DockStyle.Left;
            this.sideBar.Location = new System.Drawing.Point(0, 0);
            this.sideBar.Name = "sideBar";
            this.sideBar.Size = new System.Drawing.Size(250, 844);
            this.sideBar.TabIndex = 0;
            // 
            // firewall_tutorSettingsButton
            // 
            this.firewall_tutorSettingsButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.firewall_tutorSettingsButton.FlatAppearance.BorderSize = 0;
            this.firewall_tutorSettingsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.firewall_tutorSettingsButton.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firewall_tutorSettingsButton.ForeColor = System.Drawing.Color.Gainsboro;
            this.firewall_tutorSettingsButton.Image = ((System.Drawing.Image)(resources.GetObject("firewall_tutorSettingsButton.Image")));
            this.firewall_tutorSettingsButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.firewall_tutorSettingsButton.Location = new System.Drawing.Point(0, 429);
            this.firewall_tutorSettingsButton.Name = "firewall_tutorSettingsButton";
            this.firewall_tutorSettingsButton.Size = new System.Drawing.Size(250, 45);
            this.firewall_tutorSettingsButton.TabIndex = 5;
            this.firewall_tutorSettingsButton.Text = "         Settings";
            this.firewall_tutorSettingsButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.firewall_tutorSettingsButton.UseVisualStyleBackColor = true;
            this.firewall_tutorSettingsButton.Click += new System.EventHandler(this.firewall_tutorSettingsButton_Click);
            // 
            // firewall_tutorialButton
            // 
            this.firewall_tutorialButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.firewall_tutorialButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.firewall_tutorialButton.FlatAppearance.BorderSize = 0;
            this.firewall_tutorialButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.firewall_tutorialButton.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firewall_tutorialButton.ForeColor = System.Drawing.Color.Gainsboro;
            this.firewall_tutorialButton.Image = ((System.Drawing.Image)(resources.GetObject("firewall_tutorialButton.Image")));
            this.firewall_tutorialButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.firewall_tutorialButton.Location = new System.Drawing.Point(0, 384);
            this.firewall_tutorialButton.Name = "firewall_tutorialButton";
            this.firewall_tutorialButton.Size = new System.Drawing.Size(250, 45);
            this.firewall_tutorialButton.TabIndex = 4;
            this.firewall_tutorialButton.Text = "         Tutorial";
            this.firewall_tutorialButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.firewall_tutorialButton.UseVisualStyleBackColor = false;
            this.firewall_tutorialButton.Click += new System.EventHandler(this.firewall_tutorialButton_Click);
            // 
            // firewall_tutorHelpButton
            // 
            this.firewall_tutorHelpButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.firewall_tutorHelpButton.FlatAppearance.BorderSize = 0;
            this.firewall_tutorHelpButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.firewall_tutorHelpButton.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firewall_tutorHelpButton.ForeColor = System.Drawing.Color.Gainsboro;
            this.firewall_tutorHelpButton.Image = ((System.Drawing.Image)(resources.GetObject("firewall_tutorHelpButton.Image")));
            this.firewall_tutorHelpButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.firewall_tutorHelpButton.Location = new System.Drawing.Point(0, 339);
            this.firewall_tutorHelpButton.Name = "firewall_tutorHelpButton";
            this.firewall_tutorHelpButton.Size = new System.Drawing.Size(250, 45);
            this.firewall_tutorHelpButton.TabIndex = 3;
            this.firewall_tutorHelpButton.Text = "         Help";
            this.firewall_tutorHelpButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.firewall_tutorHelpButton.UseVisualStyleBackColor = true;
            this.firewall_tutorHelpButton.Click += new System.EventHandler(this.firewall_tutorHelpButton_Click);
            // 
            // panelMediaSubmenu
            // 
            this.panelMediaSubmenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.panelMediaSubmenu.Controls.Add(this.firewall_tutorAboutButton);
            this.panelMediaSubmenu.Controls.Add(this.firewall_tutorViewRulesButton);
            this.panelMediaSubmenu.Controls.Add(this.firewall_tutorCheckPacketButton);
            this.panelMediaSubmenu.Controls.Add(this.firewall_tutorAddRuleButton);
            this.panelMediaSubmenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelMediaSubmenu.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panelMediaSubmenu.Location = new System.Drawing.Point(0, 178);
            this.panelMediaSubmenu.Name = "panelMediaSubmenu";
            this.panelMediaSubmenu.Size = new System.Drawing.Size(250, 161);
            this.panelMediaSubmenu.TabIndex = 2;
            this.panelMediaSubmenu.Paint += new System.Windows.Forms.PaintEventHandler(this.panelMediaSubmenu_Paint);
            // 
            // firewall_tutorAboutButton
            // 
            this.firewall_tutorAboutButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.firewall_tutorAboutButton.FlatAppearance.BorderSize = 0;
            this.firewall_tutorAboutButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.firewall_tutorAboutButton.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firewall_tutorAboutButton.ForeColor = System.Drawing.Color.LightGray;
            this.firewall_tutorAboutButton.Image = ((System.Drawing.Image)(resources.GetObject("firewall_tutorAboutButton.Image")));
            this.firewall_tutorAboutButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.firewall_tutorAboutButton.Location = new System.Drawing.Point(0, 120);
            this.firewall_tutorAboutButton.Name = "firewall_tutorAboutButton";
            this.firewall_tutorAboutButton.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.firewall_tutorAboutButton.Size = new System.Drawing.Size(250, 40);
            this.firewall_tutorAboutButton.TabIndex = 4;
            this.firewall_tutorAboutButton.Text = "     View Results";
            this.firewall_tutorAboutButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.firewall_tutorAboutButton.UseVisualStyleBackColor = true;
            this.firewall_tutorAboutButton.Click += new System.EventHandler(this.firewall_tutorViewresults_Button_Click_1);
            // 
            // firewall_tutorViewRulesButton
            // 
            this.firewall_tutorViewRulesButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.firewall_tutorViewRulesButton.FlatAppearance.BorderSize = 0;
            this.firewall_tutorViewRulesButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.firewall_tutorViewRulesButton.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firewall_tutorViewRulesButton.ForeColor = System.Drawing.Color.LightGray;
            this.firewall_tutorViewRulesButton.Image = ((System.Drawing.Image)(resources.GetObject("firewall_tutorViewRulesButton.Image")));
            this.firewall_tutorViewRulesButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.firewall_tutorViewRulesButton.Location = new System.Drawing.Point(0, 80);
            this.firewall_tutorViewRulesButton.Name = "firewall_tutorViewRulesButton";
            this.firewall_tutorViewRulesButton.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.firewall_tutorViewRulesButton.Size = new System.Drawing.Size(250, 40);
            this.firewall_tutorViewRulesButton.TabIndex = 3;
            this.firewall_tutorViewRulesButton.Text = "      View Rules";
            this.firewall_tutorViewRulesButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.firewall_tutorViewRulesButton.UseVisualStyleBackColor = true;
            this.firewall_tutorViewRulesButton.Click += new System.EventHandler(this.firewall_tutorViewRulesButton_Click);
            // 
            // firewall_tutorCheckPacketButton
            // 
            this.firewall_tutorCheckPacketButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.firewall_tutorCheckPacketButton.FlatAppearance.BorderSize = 0;
            this.firewall_tutorCheckPacketButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.firewall_tutorCheckPacketButton.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firewall_tutorCheckPacketButton.ForeColor = System.Drawing.Color.LightGray;
            this.firewall_tutorCheckPacketButton.Image = ((System.Drawing.Image)(resources.GetObject("firewall_tutorCheckPacketButton.Image")));
            this.firewall_tutorCheckPacketButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.firewall_tutorCheckPacketButton.Location = new System.Drawing.Point(0, 40);
            this.firewall_tutorCheckPacketButton.Name = "firewall_tutorCheckPacketButton";
            this.firewall_tutorCheckPacketButton.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.firewall_tutorCheckPacketButton.Size = new System.Drawing.Size(250, 40);
            this.firewall_tutorCheckPacketButton.TabIndex = 2;
            this.firewall_tutorCheckPacketButton.Text = "      Check Packet";
            this.firewall_tutorCheckPacketButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.firewall_tutorCheckPacketButton.UseVisualStyleBackColor = true;
            this.firewall_tutorCheckPacketButton.Click += new System.EventHandler(this.firewall_tutorCheckPacketButton_Click);
            // 
            // firewall_tutorAddRuleButton
            // 
            this.firewall_tutorAddRuleButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.firewall_tutorAddRuleButton.FlatAppearance.BorderSize = 0;
            this.firewall_tutorAddRuleButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.firewall_tutorAddRuleButton.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firewall_tutorAddRuleButton.ForeColor = System.Drawing.Color.LightGray;
            this.firewall_tutorAddRuleButton.Image = ((System.Drawing.Image)(resources.GetObject("firewall_tutorAddRuleButton.Image")));
            this.firewall_tutorAddRuleButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.firewall_tutorAddRuleButton.Location = new System.Drawing.Point(0, 0);
            this.firewall_tutorAddRuleButton.Name = "firewall_tutorAddRuleButton";
            this.firewall_tutorAddRuleButton.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.firewall_tutorAddRuleButton.Size = new System.Drawing.Size(250, 40);
            this.firewall_tutorAddRuleButton.TabIndex = 1;
            this.firewall_tutorAddRuleButton.Text = "      Add Rules";
            this.firewall_tutorAddRuleButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.firewall_tutorAddRuleButton.UseVisualStyleBackColor = true;
            this.firewall_tutorAddRuleButton.Click += new System.EventHandler(this.firewall_tutorAddRuleButton_Click);
            // 
            // FirewallHome_button
            // 
            this.FirewallHome_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.FirewallHome_button.Dock = System.Windows.Forms.DockStyle.Top;
            this.FirewallHome_button.FlatAppearance.BorderSize = 0;
            this.FirewallHome_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FirewallHome_button.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirewallHome_button.ForeColor = System.Drawing.Color.Gainsboro;
            this.FirewallHome_button.Image = ((System.Drawing.Image)(resources.GetObject("FirewallHome_button.Image")));
            this.FirewallHome_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FirewallHome_button.Location = new System.Drawing.Point(0, 133);
            this.FirewallHome_button.Name = "FirewallHome_button";
            this.FirewallHome_button.Size = new System.Drawing.Size(250, 45);
            this.FirewallHome_button.TabIndex = 1;
            this.FirewallHome_button.Text = "         Home";
            this.FirewallHome_button.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FirewallHome_button.UseVisualStyleBackColor = true;
            this.FirewallHome_button.Click += new System.EventHandler(this.FirewallHome_button_Click);
            // 
            // panellogo
            // 
            this.panellogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.panellogo.Controls.Add(this.panel1);
            this.panellogo.Controls.Add(this.pictureBox1);
            this.panellogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panellogo.Location = new System.Drawing.Point(0, 0);
            this.panellogo.Name = "panellogo";
            this.panellogo.Size = new System.Drawing.Size(250, 133);
            this.panellogo.TabIndex = 0;
            this.panellogo.Paint += new System.Windows.Forms.PaintEventHandler(this.panellogo_Paint);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(80, 36);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(164, 58);
            this.panel1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(3, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "FireWall | Menu";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(71, 82);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panelChildForm
            // 
            this.panelChildForm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.panelChildForm.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelChildForm.BackgroundImage")));
            this.panelChildForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelChildForm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelChildForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelChildForm.Location = new System.Drawing.Point(250, 0);
            this.panelChildForm.Name = "panelChildForm";
            this.panelChildForm.Size = new System.Drawing.Size(1189, 844);
            this.panelChildForm.TabIndex = 2;
            this.panelChildForm.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1439, 844);
            this.Controls.Add(this.panelChildForm);
            this.Controls.Add(this.sideBar);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.TopMost = true;
            this.TransparencyKey = System.Drawing.Color.Transparent;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.sideBar.ResumeLayout(false);
            this.panelMediaSubmenu.ResumeLayout(false);
            this.panellogo.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel sideBar;
        private System.Windows.Forms.Panel panelMediaSubmenu;
        private System.Windows.Forms.Button FirewallHome_button;
        private System.Windows.Forms.Panel panellogo;
        private System.Windows.Forms.Button firewall_tutorViewRulesButton;
        private System.Windows.Forms.Button firewall_tutorCheckPacketButton;
        private System.Windows.Forms.Button firewall_tutorAddRuleButton;
        private System.Windows.Forms.Button firewall_tutorialButton;
        private System.Windows.Forms.Button firewall_tutorHelpButton;
        private System.Windows.Forms.Button firewall_tutorSettingsButton;
        private System.Windows.Forms.Panel panelChildForm;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button firewall_tutorAboutButton;
    }
}

